# nrfutil-trace documentation

# `trace` command quick guide

nRF Util's `trace` command is a CLI tool for converting trace data types to trace capture types.

The command supports multiple trace conversions that can be hooked up to other software, such as Wireshark, the open-source network protocol analyzer.

This tool requires [SEGGER J-Link](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/installing.html#prerequisites).

See the [Trace command](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-trace/guides/tracing.html) section on the TechDocs platform for complete documentation.

## Available subcommands

`trace` offers several tracing-related subcommands.  To see the list of subcommands and available device operations, run `nrfutil trace --help`.

## `nrfutil trace lte` usage examples

Perform tracing of LTE modem data. The subcommand passes along a set of preset configurations that will be used for the tracing.

For more examples, see [other documentation pages](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-trace/guides/tracing.html).

### Capture trace data from an nRF91 modem

`trace` can be used to collect UART traces from an nRF91 SiP. The trace can be used to analyze the communication between the device and the LTE network.

To use tracing, the nRF9160 DK must have modem trace enabled.

For example, you can use the following command to collect trace data from a serialport `COM10` to a raw file `raw-file.bin`:
```
nrfutil trace lte --input-serialport COM10 --output-raw raw-file.bin
```
The process initiated with this command runs until you forcibly shut it down (for example, using CTRL-C).

Passing the `--input-serialport` option with the serial port name makes `trace` use the default serial port settings
(1000000 baudrate, 8 data bits, no parity, 1 stop bit, or in short hand conventional format 1000000/8/N/1).

### Capturing with custom serial port configuration

As mentioned in the section above, you can use the `--input-serialport` argument with the serial port name to have `trace`
use the default serial port settings (`1000000/8/N/1`). You can customize these settings by passing additional options to `--input-serialport`.

For example, the following command will perform the same trace as before, but with baudrate set to 9600, flow control
set to software, parity set to even and two stop bits:

```
nrfutil trace lte --input-serialport port=COM10,baud_rate=9600,stop_bits=2,parity=even,flow_control=software --output-raw raw-file.bin
```

See [Capturing trace data from an nRF9160 modem to a binary file](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-trace/guides/tracing_9160_modem_binary.html) for more information.

## `nrfutil trace stm` usage examples

Perform tracing of STM trace data. Like `nrfutil trace lte`, a set of preset configurations will be used for the tracing.

### Capture trace from STM to binary format

Trace from STM can be captured in similar style as with the `nrfutil trace lte` subcommand. STM trace data in a file `stm_trace.bin`
can be captured to binary format by running the following command:
```
nrfutil trace stm --input-file stm_trace.bin --output-raw out.bin
```

### Capture trace from STM to ASCII format

Similarily to the previous command, trace from STM can be captured to an ASCII-formatted file with the `output-ascii` flag:
```
nrfutil trace stm --input-file stm_trace.bin --output-ascii out.txt
```

### Capture trace from STM over TPIU

You can also capture STM trace over the Trace Port Interface Unit (TPIU). This option requires a J-Trace Cortex-M probe and is only supported for nRF54H20.

You can use the `stm` subcommand with the `--input-jtrace-serial-number` flag and the serial number of the connected J-Trace probe:
```
nrfutil trace stm --input-jtrace-serial-number <SERIALNUMBER> --stdout ascii
```


## `nrfutil trace process` usage examples

In some cases, the preset configurations made by the other subcommands are not sufficient. You may want to modify the configurations
yourself.

For more details, see [Customizing the trace configuration](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-trace/guides/tracing_customizing_configuration.html).

### Saving a custom trace collection configuration file

You can use `trace` with the `--keep-configuration` parameter to generate a JSON configuration file in the current
working directory, in which the current trace configuration is saved:
```
nrfutil trace lte --input-file modem_trace.bin --output-pcapng out.pcapng --keep-configuration
```

### Using the custom trace configuration file

Once you are done with editing your configuration, you can use the `process` subcommand with the `--config` flag to apply the configuration file:
```
nrfutil trace process --config <path/to/trace/collection/config.json>
```
