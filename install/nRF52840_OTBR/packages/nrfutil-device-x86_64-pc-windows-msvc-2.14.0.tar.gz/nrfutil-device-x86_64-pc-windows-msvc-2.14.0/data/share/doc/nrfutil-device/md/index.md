# nrfutil-device documentation

# `device` command quick guide

nRF Util's `device` command is a CLI tool for performing a series of device operations, such as listing or programming.
The tool is meant for use with Nordic Semiconductor devices.

See the [Device command](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html) section on the TechDocs platform for complete documentation.

**Note:** If you are working on Linux, you need [nrf-udev installed](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/installing.html) to use the `device` command.

## Available subcommands

To see the list of subcommands and available device operations, run `nrfutil device --help`.

### Traits

A device trait is a general property or capability a device has. All devices are
annotated with traits, which are used to determine whether a device supports a
given device operation or programming method.

Examples:

* `mcuboot` trait: The device has support for programming over MCUboot.
* `jlink` trait: The device has a J-Link probe and supports operations like `erase`, `recover`, ...
* `serialPorts` trait: The device has serial ports.

See the help for `--traits` (for example in `nrfutil device list --help`) for the full list of available
traits and their descriptions.

### Detection options

Detection options are flags available for the `device` command and its subcommands.<br/>
You can use detection options to specify how nRF Util commands should behave when interacting with a device, for example to narrow down the results of a command.

The following table lists the detection options available for the `device` command and its subcommands:

* `--family`: Set the expected device family for the automatic device detection.<br/>
  For example, if you use `--family nrf52` with the `nrfutil device program` command, the command will return an error if the connected device does not belong to the nRF52 Series family.
* `--x-sdfw-variant` (nRF54H20 only): Indicate to nRF Util the Secure Domain Firmware (SDFW) variant that is running on the nRF54H20 device.<br/>
  By default, nRF Util assumes that the device is running the IronSide Secure Element.
  If the device is running a different variant, for example SUIT, you can use the command `nrfutil device recover --x-sdfw-variant suit` to inform nRF Util about this. This affects nRF Util's behavior when recovering the nRF54H20 device.

## Basic usage examples

Here are some basic usage examples of the `device` command:

* Check the version information for your installed device command. This also shows your installed J-Link version:

    ```
    nrfutil device --version
    ```

* List all devices with a SEGGER J-Link on-board debugger:

    ```
    nrfutil device list --traits seggerUsb
    ```

* Program a specific device with serial number `000683298616`:

    ```
    nrfutil device program --serial-number 000683298616 --firmware path_to_some_firmware.hex
    ```

* Program all devices with a Nordic DFU trigger interface:

    ```
    nrfutil device program --traits nordicDfu --firmware path_to_some_dfu_package.zip
    ```
