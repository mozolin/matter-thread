# nrfutil-nrf5sdk-tools documentation

# nRF5 SDK tools

nRF Util's `nrf5sdk-tools` command provides all functionalities available in nRF Util versions prior to v7.0.0.

## Usage instructions

See [nRF Util for nRF5 SDK documentation](https://docs.nordicsemi.com/bundle/nrfutil/page/guides-nrf5sdk/intro.html)
for usage instructions.

See also `nrfutil nrf5sdk-tools --help`.

## Command mappings

`nrfutil nrf5sdk-tools` provides the following command mappings for subcommands that were provided in nRF Util v6.x.x:

* `nrfutil dfu` → `nrfutil nrf5sdk-tools dfu`
* `nrfutil keys` → `nrfutil nrf5sdk-tools keys`
* `nrfutil pkg` → `nrfutil nrf5sdk-tools pkg`
* `nrfutil settings` → `nrfutil nrf5sdk-tools settings`
* `nrfutil zigbee` → `nrfutil nrf5sdk-tools zigbee`

**Note:** Individual mappings might be replaced by independent, installable nRF Util commands in the future.

## Alternative ways of obtaining nRF Util v6.x.x

If you do not want to use `nrf5sdk-tools` in nRF Util v7.0.0 and later, you can obtain nRF Util v6.x.x (corresponding to `nrfutil nrf5sdk-tools`) at the following locations:

* [GitHub nRF Util release page](https://github.com/NordicSemiconductor/pc-nrfutil/releases)
* [GitHub Nordic Semiconductor repository](https://github.com/NordicSemiconductor/pc-nrfutil)
* [pip](https://pypi.org/project/nrfutil/)
